This is an app that provides a set of Dashboards and Saved Searches to visualize the data being collected by the Splunk_TA_New_Relic add-on.

