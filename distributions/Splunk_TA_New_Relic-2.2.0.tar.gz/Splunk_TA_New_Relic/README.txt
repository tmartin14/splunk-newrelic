This is an add-on powered by the Splunk Add-on Builder.

Splunk Add-on for New Relic version 2.1.0 
Copyright (C) 2005-2017 Splunk Inc. All Rights Reserved. 

For documentation, see:
http://docs.splunk.com/Documentation/AddOns/latest/NewRelic/About
------------------------------------------------------------
